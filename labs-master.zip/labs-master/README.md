This is the Labs repository for the Practical OpenShift for Developers course. 

