#!/bin/sh

# sudo podman build -t hello-world .
docker build -t hello-world .
