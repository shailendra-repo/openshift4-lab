#!/bin/sh

# sudo podman run -it -p 8080:8080 hello-world
docker run -it -p 8080:8080 hello-world
